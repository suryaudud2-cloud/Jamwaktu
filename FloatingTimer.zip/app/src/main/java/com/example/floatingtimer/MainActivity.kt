package com.example.floatingtimer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
        }
        root.addView(TextView(this).apply {
            text = "Batas waktu scroll (menit)"
            textSize = 18f
        })
        input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("15")
            gravity = Gravity.CENTER
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = "Mulai Timer"
            setOnClickListener { startTimer() }
        })
        root.addView(Button(this).apply {
            text = "Hentikan Timer"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingTimerService::class.java)) }
        })
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun startTimer() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain' dulu", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val minutes = input.text.toString().toIntOrNull() ?: return
        if (minutes <= 0) return

        val intent = Intent(this, FloatingTimerService::class.java)
            .putExtra(FloatingTimerService.EXTRA_MINUTES, minutes)
        startForegroundService(intent)
        moveTaskToBack(true) // langsung ke background, timer tetap tampil
    }
}
