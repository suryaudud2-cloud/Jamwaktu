package com.example.floatingtimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.CountDownTimer
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class FloatingTimerService : Service() {

    companion object {
        const val EXTRA_MINUTES = "minutes"
        private const val CHANNEL_ID = "floating_timer"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var timer: CountDownTimer? = null
    private var finished = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())

        val minutes = intent?.getIntExtra(EXTRA_MINUTES, 15) ?: 15
        removeBubble()
        timer?.cancel()
        finished = false

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()

        timer = object : CountDownTimer(minutes * 60_000L, 1000L) {
            override fun onTick(msLeft: Long) {
                val s = msLeft / 1000
                bubble?.text = "%02d:%02d".format(s / 60, s % 60)
            }

            override fun onFinish() {
                finished = true
                bubble?.text = "Waktu habis!\nKetuk untuk tutup"
                (bubble?.background as? GradientDrawable)?.setColor(Color.parseColor("#E53935"))
                vibrate()
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun showBubble() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }

        val view = TextView(this).apply {
            text = "--:--"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
            background = GradientDrawable().apply {
                cornerRadius = 80f
                setColor(Color.parseColor("#CC1E88E5")) // biru semi-transparan
            }
        }

        // Geser (drag) + ketuk
        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(view, params)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && finished) stopSelf() // ketuk saat selesai = tutup
                }
            }
            true
        }

        wm.addView(view, params)
        bubble = view
    }

    private fun removeBubble() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
    }

    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 500), -1))
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Timer Melayang", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Timer scroll berjalan")
            .setContentText("Timer tampil di atas aplikasi lain")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        timer?.cancel()
        removeBubble()
        super.onDestroy()
    }
}
